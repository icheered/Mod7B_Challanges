class MediumState:
    IDLE = 1
    COLLISION = 2
    SUCCESS = 3


class TransmissionType:
    SILENT = 1
    DATA = 2
    NO_DATA = 3
